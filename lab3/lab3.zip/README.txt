
Group member1:
Name:  Feichao Qian
PID:   A53091625
Email: feqian@ucsd.edu

Group member2:
Name:  Shiunn An Lu
PID:   A53087777
Email: shl423@eng.ucsd.edu

===========================================================

Q: How to run scripts?
A: $./run.sh

Q: Where is the output file of BigramCount.java?
A: path = ./Data/result.txt



